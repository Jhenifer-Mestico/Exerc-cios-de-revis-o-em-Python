for x in range(1,51):
    
    if x % 2 !=0:
        print('N´mero ímpar:', x)
    else:
        print('Número par:', x)
    print('Resto da divisão:' , x%2)  
        
  

    
    
