n1 = int(input('Primeiro valor:'))
n2 = int(input('Segundo valor:'))
n3 = int(input('Terceiro valor:'))

if (n1> n2) and (n1>n2):
    print('n1 é o maior número')

elif (n2>n1) and (n2>n3):
    print('n2 é o maior número')

elif (n3>n1) and (n3>n2):
    print(' n3 é o maior número:')

else:
    print ('Todos os números devem ser difrentes ')
