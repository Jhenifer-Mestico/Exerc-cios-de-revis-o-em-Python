letra = input('Digite uma letra:')

if letra == 'a' or letra=='e' or letra== 'i' or letra== 'o' or letra== 'u':
    print('É uma vogal')
else:
    print('Letra é uma consoante')

