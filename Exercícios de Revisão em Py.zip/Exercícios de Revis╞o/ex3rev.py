valorHora = float(input('Valor hora:S'))
horas = int(input('Horas trabalhadas:'))

print('Total no mês:', valorHora*horas)
