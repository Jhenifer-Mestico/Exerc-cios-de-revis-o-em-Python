valor1 = int(input('Valor1:'))+1
valor2 = int(input('Valor2:'))

for y in range (valor1,valor2):
    print('Número:', y)
