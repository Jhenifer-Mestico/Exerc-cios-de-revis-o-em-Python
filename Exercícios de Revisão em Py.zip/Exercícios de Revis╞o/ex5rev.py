n1 = int(input('Digite o primeito número:'))
n2 = int(input('Digite o segundo número:'))

if n1>n2:
    print('Onúmero n1 é maior:[',n1,']')

elif n2>n1:
    print('Onúmero n1 é maior:[',n2,']')

else:
    print('O número nw é igual ao n1:')
