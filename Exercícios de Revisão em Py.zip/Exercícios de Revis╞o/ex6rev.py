valor = int(input('Digite um valor:'))

if valor < 0:
    print ('Valor negativo')
elif valor >0:
    print ('Valor positivo')
