numero1 = int(input('Digite o primeino número:'))
numero2 = input('Digite o segundo número:')
numero2 = int(numero2)


soma= numero1 + numero2

print('Soma dos números é:' , soma)
